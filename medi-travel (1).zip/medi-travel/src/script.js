document.getElementById("bookingForm").addEventListener("submit", function(event) {
    event.preventDefault();

    let name = document.getElementById("name").value;
    let passport = document.getElementById("passport").value;
    let nationalId = document.getElementById("nationalId").value;
    let phone = document.getElementById("phone").value;
    let destination = document.getElementById("destination").value;
    let bookingDate = new Date().toLocaleDateString("ar-EG");

    let bookingData = { name, passport, nationalId, phone, destination, bookingDate };

    let bookings = JSON.parse(localStorage.getItem("bookings")) || [];
    bookings.push(bookingData);
    localStorage.setItem("bookings", JSON.stringify(bookings));

    alert("تم الحجز بنجاح!");
    document.getElementById("bookingForm").reset();
});

// تسجيل الدخول للأدمن بكلمة السر
document.getElementById("adminLogin").addEventListener("click", function() {
    let password = prompt("أدخل كلمة السر:");

    if (password === "MEDI Travel 2025***") {
        document.getElementById("adminPanel").style.display = "block";
        loadBookings();
    } else {
        alert("كلمة السر غير صحيحة!");
    }
});

// تحميل وحذف السجلات في لوحة الأدمن
function loadBookings() {
    let bookings = JSON.parse(localStorage.getItem("bookings")) || [];
    let bookingList = document.getElementById("bookingList");
    bookingList.innerHTML = "";

    bookings.forEach((booking, index) => {
        let row = bookingList.insertRow();

        row.insertCell(0).textContent = booking.name;
        row.insertCell(1).textContent = booking.passport;
        row.insertCell(2).textContent = booking.nationalId;
        row.insertCell(3).textContent = booking.phone;
        row.insertCell(4).textContent = booking.destination;
        row.insertCell(5).textContent = booking.bookingDate;

        let deleteBtn = document.createElement("button");
        deleteBtn.textContent = "❌ حذف";
        deleteBtn.onclick = function() {
            bookings.splice(index, 1);
            localStorage.setItem("bookings", JSON.stringify(bookings));
            loadBookings();
        };

        row.insertCell(6).appendChild(deleteBtn);
    });
}